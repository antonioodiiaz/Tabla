import java.util.Scanner;

public class Ejercicio2AntDiaz{


     /**
     *Esta funcion genera un array bidimensional
     *@param el numero de filas de mi array
     *@param el numero de columnas de mi array
     *@return devuelve mi array
     */
     public static int[][] genera_array(int filas, int columnas){

          int[][] array=new int[filas][columnas];

          for (int i=0;i<filas ;i++ ) {
               for (int x=0;x<columnas ;x++ ) {
                    array[i][x]=(int)((Math.random()*10)+1);
               }
          }
          return array;
     }


     /**
     *Esta funcion imprime un array bidimensional sin formato
     *@param le introduzco el array a imprimir
     *@param el numero de filas de mi array
     *@param el numero de columnas de mi array
     */
     public static void imprime_sin_formato(int[][] array, int filas, int columnas){

          for (int i=0;i<filas ;i++ ) {
               for (int x=0;x<columnas ;x++ ) {
                    System.out.print(array[i][x]+"\t");
               }
               System.out.println("");
          }
     }

     /**
     *Esta funcion suma el total de cada fila o el de las columnas
     *@param introduzco mi array
     *@param el numero de filas de mi array
     *@param el numero de columnas de mi array
     *@param la opcion que quiero si filas o columnas
     *@return devuelve un array con la suma de filas
     */
     public static int[] suma_array(int[][] array, int filas, int columnas, boolean opcion){

          int[] suma=new int[filas];

          for (int i=0;i<filas ;i++ ) {
               for (int x=0;x<columnas ;x++ ) {
                    if (opcion==true) {
                         suma[i]=suma[i]+array[i][x];
                    }else{
                         suma[i]=suma[i]+array[x][i];
                    }
               }
          }
          return suma;
     }


     /**
     *Esta funcion devuelve el numero maximo de la fila o el de la columna
     *@param introduzco mi array
     *@param el numero de filas de mi array
     *@param el numero de columnas de mi array
     *@param la opcion que quiero si filas o columnas
     *@return devuelve un array con el maximo de la fila o la columna
     */
     public static int[] max_array(int[][] array, int filas, int columnas, boolean opcion){

          int[] max=new int[filas];

          for (int i=0;i<filas ;i++ ) {
               for (int x=0;x<columnas ;x++ ) {
                    if (opcion==true) {
                         if (max[i]<array[i][x]) {
                              max[i]=array[i][x];
                         }
                    }else if (opcion==false) {
                         if (max[i]<array[x][i]) {
                              max[i]=array[x][i];
                         }
                    }

               }
          }
          return max;
     }


     /**
     *Esta funcion devuelve el numero de sietes que contiene la fila o la columna
     *@param introduzco mi array
     *@param el numero de filas de mi array
     *@param el numero de columnas de mi array
     *@param la opcion que quiero si filas o columnas
     *@return devuelve un array con los sietes que contiene la fila o la columna
     */
     public static int[] sietes_array(int[][] array, int filas, int columnas, boolean opcion){

          int[] sietes=new int[filas];

          for (int i=0;i<filas ;i++ ) {
               for (int x=0;x<columnas ;x++ ) {
                    if (opcion==true) {
                         if (array[i][x]==7) {
                              sietes[i]=sietes[i]+1;
                         }
                    }else if (opcion==false) {
                         if (array[x][i]==7) {
                              sietes[i]=sietes[i]+1;
                         }
                    }
               }
          }
          return sietes;
     }


     /**
     *Esta funcion devuelve el numero de pares que contiene la fila o la columna
     *@param introduzco mi array
     *@param el numero de filas de mi array
     *@param el numero de columnas de mi array
     *@param la opcion que quiero si filas o columnas
     *@return devuelve un array con los pares que contiene la fila o la columna
     */
     public static int[] pares_array(int[][] array, int filas, int columnas, boolean opcion){

          int[] pares=new int[filas];

          for (int i=0;i<filas ;i++ ) {
               for (int x=0;x<columnas ;x++ ) {
                    if (opcion==true) {
                         if (array[i][x]%2==0) {
                              pares[i]=pares[i]+1;
                         }
                    }else if (opcion==false) {
                         if (array[x][i]%2==0) {
                              pares[i]=pares[i]+1;
                         }
                    }
               }
          }
          return pares;
     }


     /**
     *Esta funcion imprime el array con formato1. Llama las funciones suma,
     *el maximo, los sietes y los pares y luego las imprime en el formato1.
     *@param introduzco mi array
     *@param el numero de filas de mi array
     *@param el numero de columnas de mi array
     */
     public static void imprime_con_formato1(int[][] array, int filas, int columnas){

          int columnas1=columnas+4;
          //Creo un string con la cabecera de mi array
          String[] fila1=new String[columnas1];
          fila1[columnas1-1]="Pares";
          fila1[columnas1-2]="Sietes";
          fila1[columnas1-3]="Max";
          fila1[columnas1-4]="Sum";

          //Creo todos los arrays para los metodos suma, max, sietes y pares de la filas
          int[] sumaFilas=new int[filas];
          int[] maxFilas=new int[filas];
          int[] sietesFilas=new int[filas];
          int[] paresFilas=new int[filas];

          //Llamo a todos los metodos y los introduzco en los arrays de filas anteriores
          sumaFilas=suma_array(array, filas, columnas, true);
          maxFilas=max_array(array, filas, columnas, true);
          sietesFilas=sietes_array(array, filas, columnas, true);
          paresFilas=pares_array(array, filas, columnas, true);

          //Introduzco en mi array string el numero de columnas
          for (int i=0;i<columnas ;i++ ) {
                    fila1[i]="Col "+i;
          }

          //Imprimo la cabecera
          for (int x=0;x<columnas1 ;x++ ) {
               System.out.print(fila1[x]+"\t");
          }
          System.out.println("");

          //Imprimo mi array con la suma, el maximo, los sietes y los pares
          for (int i=0;i<filas ;i++ ) {
               for (int x=0;x<columnas ;x++ ) {
                    System.out.print(array[i][x]+"\t");
               }
               System.out.print(sumaFilas[i]+"\t"+maxFilas[i]+"\t"+sietesFilas[i]+"\t"+paresFilas[i]);
               System.out.println("");
          }

     }


     /**
     *Esta funcion imprime los arrays unidimensionales
     *@param el array a imprimir
     *@param el tamaño del array
     */
     public static void imprime(int[] array, int sizeArray){

          for (int i=0;i<sizeArray ;i++ ) {
               System.out.print(array[i]+"\t");
          }

     }


     /**
     *Esta funcion imprime el array con formato2. Llama las funciones suma,
     *el maximo, los sietes y los pares para filas y columnas, y luego las imprime en el formato2
     *@param introduzco mi array
     *@param el numero de filas de mi array
     *@param el numero de columnas de mi array
     */
     public static void imprime_con_formato2(int[][] array, int filas, int columnas){

          int columnas1=columnas+4;
          //Creo un string con la cabecera de mi array
          String[] fila1=new String[columnas1];
          fila1[columnas1-1]="Pares";
          fila1[columnas1-2]="Sietes";
          fila1[columnas1-3]="Max";
          fila1[columnas1-4]="Sum";

          //Creo todos los arrays para los metodos suma, max, sietes y pares de las filas
          int[] sumaFilas=new int[filas];
          int[] maxFilas=new int[filas];
          int[] sietesFilas=new int[filas];
          int[] paresFilas=new int[filas];

          //Creo todos los arrays para los metodos suma, max, sietes y pares de las columnas
          int[] sumaColumnas=new int[columnas];
          int[] maxColumnas=new int[columnas];
          int[] sietesColumnas=new int[columnas];
          int[] paresColumnas=new int[columnas];

          //Llamo a todos los metodos y los introduzco en los arrays de filas anteriores
          sumaFilas=suma_array(array, filas, columnas, true);
          maxFilas=max_array(array, filas, columnas, true);
          sietesFilas=sietes_array(array, filas, columnas, true);
          paresFilas=pares_array(array, filas, columnas, true);

          //Llamo a todos los metodos y los introduzco en los arrays de filas anteriores
          sumaColumnas=suma_array(array, columnas, filas, false);
          maxColumnas=max_array(array, columnas, filas, false);
          sietesColumnas=sietes_array(array, columnas, filas, false);
          paresColumnas=pares_array(array, columnas, filas, false);

          //Introduzco en mi array string el numero de columnas
          for (int i=0;i<columnas ;i++ ) {
                    fila1[i]="Col "+i;
          }

          //Imprimo la cabecera
          for (int x=0;x<columnas1 ;x++ ) {
               System.out.print(fila1[x]+"\t");
          }
          System.out.println("");

          //Imprimo mi array con la suma, el maximo, los sietes y los pares de las filas
          for (int i=0;i<filas ;i++ ) {
               for (int x=0;x<columnas ;x++ ) {
                    System.out.print(array[i][x]+"\t");
               }
               System.out.print(sumaFilas[i]+"\t"+maxFilas[i]+"\t"+sietesFilas[i]+"\t"+paresFilas[i]);
               System.out.println("");
          }

          //Imprimo mi array con la suma, el maximo, los sietes y los pares de las columnas
          imprime(sumaColumnas, columnas);
          System.out.print(fila1[columnas1-4]+"\t");
          System.out.println("");
          imprime(maxColumnas, columnas);
          System.out.print(fila1[columnas1-3]+"\t");
          System.out.println("");
          imprime(sietesColumnas, columnas);
          System.out.print(fila1[columnas1-2]+"\t");
          System.out.println("");
          imprime(paresColumnas, columnas);
          System.out.print(fila1[columnas1-1]+"\t");
          System.out.println("");

     }


     /**
     *En el metodo main vamos a llamar a todas las funciones
     *y voy a hacer todas las pruebas pertinentes
     *para ver que todas las funciones pertinentes estan correctas
     */
     public static void main(String[] args) {

          //Creo mis variables y mi array
          int filas=5;
          int columnas=6;
          int opcion;
          int[][] array=new int[filas][columnas];
          Scanner teclado=new Scanner(System.in);

          //Explico las opciones de mi menu
          System.out.println("0. Genera mi array bidimensional y lo imprime sin formato");
          System.out.println("1. Genera mi array bidimensional y lo imprime con formato1");
          System.out.println("2. Genera mi array bidimensional y lo imprime con formato2");
          opcion=teclado.nextInt();

          //Realizo mi menu
          switch (opcion) {
               case 0:
                    //Llamo a mi funcion genera array y la imprimo por pantalla sin formato
                    array=genera_array(filas, columnas);
                    imprime_sin_formato(array, filas, columnas);
                    break;
               case 1:
                    //Llamo a mi funcion genera array y la imprimo con el primer formato
                    array=genera_array(filas, columnas);
                    imprime_con_formato1(array, filas, columnas);
                    break;
               case 2:
                    //Llamo a mi funcion genera array y la imprimo con el segundo formato
                    array=genera_array(filas, columnas);
                    imprime_con_formato2(array, filas, columnas);
                    break;
               default:
                    System.out.println("El numero introducido no concuerda con ninguno de mi menu");
          }
     }
}
